# Matt Butler. Harper Adams University 2022
# Test routine to explore the node-red 'exec' block

import time
import sys
import datetime

now = datetime.datetime.now()
print("Current date and time: <br>")
print(str(now))


sys.stderr.write("This is error msg")
cheese


