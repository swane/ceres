import time
import sys


while(1):
    
    sys.stderr.write("/pussy.jpg")

    time.sleep(0.1)

    sys.stderr.write("/viewfolder/dog.jpg")

    time.sleep(0.1)



