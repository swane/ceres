#! /bin/bash


/home/pi/Desktop/ceres_startup/cam2.py

