#! /bin/bash

source /opt/ros/kinetic/setup.bash
source /home/pi/catkin_ws/devel/setup.bash


