#! /bin/bash

source /opt/ros/kinetic/setup.bash
source /home/pi/catkin_ws/devel/setup.bash

python /home/pi/catkin_ws/src/ceres/src/4_nav_path_points.py

